class Implicit {
  public static void main(String[] args) {
    
    int num = 10;
    System.out.println("The integer value: " + num);

   
    double data = num;
    System.out.println("The double value: " + data);
  }
}
