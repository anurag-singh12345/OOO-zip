package com.simpli.demo;

public class publicDemo {
	public static void main(String[] args) {
		A a1=new A();
		a1.x=200;
		
		A a2=new A();
		a2.x=300;
		System.out.println(a1.s);
		System.out.println(a2.s);
		System.out.println(A.s);
		
		A.s=110;
		
		System.out.println(a1.s);
		System.out.println(a2.s);
		System.out.println(A.s);
		
		a1.s=150;
		System.out.println(a1.s);
		System.out.println(a2.s);
		System.out.println(A.s);
		
	}

}

class {
	static int s=100;
	int x=150;
	static public void s1() {
		System.out.println("Inside static method s1");
	}
}
