class Shape {
    
    private String color;

    
    public Shape(String color) {
        this.color = color;
    }

    
    public String getColor() {
        return color;
    }

    
    public void draw() {
        System.out.println("Drawing a shape with color: " + color);
    }
}

class Circle extends Shape {
    private double radius;


    public Circle(String color, double radius) {
        super(color);
        this.radius = radius;
    }

  
    
    public void draw() {
        System.out.println("Drawing a circle with color: " + getColor() + ", radius: " + radius);
    }

    
    public double calculateArea() {
        return Math.PI * radius * radius;
    }
}

public class ObjectOrientedDemo {

    public static void main(String[] args) {
       
        Shape genericShape = new Shape("Red");
        Circle myCircle = new Circle("Blue", 5.0);

       
        System.out.println("Color of the generic shape: " + genericShape.getColor());
        genericShape.draw();

        System.out.println("\nColor of the circle: " + myCircle.getColor());
        myCircle.draw();

       
        Shape polymorphicShape = new Circle("Green", 7.5);
        polymorphicShape.draw(); 

    
        System.out.println("\nArea of the circle: " + ((Circle) polymorphicShape).calculateArea());
    }
}