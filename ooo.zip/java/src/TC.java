import java.util.Scanner;

public class TryCatchExample {

    public static void main(String[] args) {
        
        divideNumbers();

        handleInputMismatch();
    }

    private static void divideNumbers() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Example 1: Divide two numbers");
        System.out.print("Enter numerator: ");
        int numerator = scanner.nextInt();

        System.out.print("Enter denominator: ");
        int denominator = scanner.nextInt();

        try {
            int result = numerator / denominator;
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        }
    }

    private static void handleInputMismatch() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\nExample 2: Handle input mismatch");
        System.out.print("Enter an integer: ");

        try {
            int number = scanner.nextInt();
            System.out.println("You entered: " + number);
        } catch (Exception e) {
            System.out.println("Error: Input mismatch. Please enter a valid integer.");
        }
    }
}