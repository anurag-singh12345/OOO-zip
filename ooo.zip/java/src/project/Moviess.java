import java.util.*;
class seat
{	
	int seatNumber;
	boolean booked;
	Seat(int seatNumber)
	{
		this.seatNumber=seatNumber;
		this.booked=false;	
	}	
}
class show
{
	Date date;
	String time;
	List<Seat>seats;
	
	Show(Date date,String time,int numberOfSeats)
	{
		this.date=date;
		this.time=time;
		this.seats=new ArrayList<>();
		for(int i=1;i<=numberOfSeats;i++)
		{
			seats.add(new Seat(i));
		}
	}
	
}
class Booking
{
	String movieName;
	List<Show> shows;
	
	Booking(String movieName)
	{
		this.movieName=movieName;
		this.shows=new ArrayList<>();
	}
	void addShow(Date date,String time,int numberOfSeats)
	{
		shows.add(new Show(date,time,numberOfSeats));
		
	}
	
}
class MovieTicketBookingSimulator
{
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) 
	{
		Booking booking =new Booking("Inception");
		booking.addShow(new Date(),"10:00 AM",50);
		booking.addShow(new Date(),"02:00 PM",50);
		while(true)
			
		 {
			
			System.out.println("1.View Shows");
			System.out.println("2.Book Ticket");
			System.out.println("3.Exit");
			System.out.print("Enter your choice:");
			int choice=scanner.nextInt();
			switch(choice)
			
			{	
			case 1:
				viewShows(booking);
				break;
			case 2:
				bookTicket(booking);
				break;
			case 3:
				System.out.println("Exiting...");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice.Try again.");		
		   }
	     }
	}
	private static void viewShows(Booking booking) 
	{
		for(int i=0;i<booking.shows.size();i++) 
		{
			
			Show show =booking.shows.get(i);
			System.out.println((i+1)+"."+show.date+" "+show.time);
		}
	}
	private static void bookTicket(Booking booking)
	{
		
		viewShows(booking);
		System.out.print("Select a show:");
		int showIndex=scanner.nextInt()-1;
		if(showIndex >=0 && showIndex<booking.shows.size())
		{		
			Show show=booking.shows.get(showIndex);
			System.out.println("Available Seats for"+show.date+" "+show.time+":");
			for(Seat seat:show.seats) 
			{
				if(!seat.booked) 
				{				
					System.out.print(seat.seatNumber+"");
					
				}
			}
			System.out.println();
			System.out.print("Enter seat number:");
			int seatNumber=scanner.nextInt();
			if(seatNumber>=1 && seatNumber<=show.seats.size()) 
			{
				Seat selectedSeat=show.seats.get(seatNumber-1);
				
				if(!selectedSeat.booked) 
				{
					
					selectedSeat.booked=true;
					System.out.println("Ticket booked successfully!");
				}
				else
				{
					System.out.println("Seat already booked.Please choose another seat.");		
				}
				else 
				{
					System.out.println("Invalid seat number.");
				}
				else 
				{
					System.out.println("Invalid show selection.");
				}
			}
		}
	}
}
