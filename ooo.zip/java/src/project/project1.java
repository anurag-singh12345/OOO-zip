import java.util.*;
class MovieTicketBooking {
    
    private static int totalSeats = 50;
    private static int bookedSeats = 0;

    private static String frontDeskUsername = "admin";
    private static String frontDeskPassword = "password";

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        loginToFrontDesk();
    }

    private static void loginToFrontDesk() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (username.equals(frontDeskUsername) && password.equals(frontDeskPassword)) {
            System.out.println("Login successful!");
            showFrontDeskOptions();
        } else {
            System.out.println("Invalid credentials. Please try again.");
            loginToFrontDesk();
        }
    }

    private static void showFrontDeskOptions() {
        System.out.println("\nFront Desk Options:");
        System.out.println("1. Update Password");
        System.out.println("2. View Seating Arrangement");
        System.out.println("3. Book Ticket");
        System.out.println("4. View Booking Status");
        System.out.println("5. Exit");

        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); 

        switch (choice) {
            case 1:
                updatePassword();
                break;
            case 2:
                viewSeatingArrangement();
                break;
            case 3:
                bookTicket();
                break;
            case 4:
                viewBookingStatus();
                break;
            case 5:
                System.out.println("Exiting program. Thank you!");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
                showFrontDeskOptions();
        }
    }

    private static void updatePassword() {
        System.out.print("Enter the new password: ");
        frontDeskPassword = scanner.nextLine();
        System.out.println("Password updated successfully.");
        showFrontDeskOptions();
    }

    private static void viewSeatingArrangement() {
        System.out.println("Seating Arrangement for Date and Show Time");
        showFrontDeskOptions();
    }

    private static void bookTicket() {
    	
        if (bookedSeats < totalSeats) {
            bookedSeats++;
            System.out.println("Ticket booked successfully!");
        } else {
            System.out.println("Sorry, all seats are booked.");
        }
        showFrontDeskOptions();
    }

    private static void viewBookingStatus() {
        System.out.println("Booking Status:");
        System.out.println("Total Seats: " + totalSeats);
        System.out.println("Booked Seats: " + bookedSeats);
        System.out.println("Available Seats: " + (totalSeats - bookedSeats));
        showFrontDeskOptions();
    }
}
