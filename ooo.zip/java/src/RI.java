
class ThreadByExtending extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread by extending: Count " + i);
            try {
                Thread.sleep(500); // Pause for 500 milliseconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
class ThreadByImplementing implements Runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread by implementing: Count " + i);
            try {
                Thread.sleep(500); // Pause for 500 milliseconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class ThreadCreationExample {

    public static void main(String[] args) {
        
        ThreadByExtending threadByExtending = new ThreadByExtending();
        threadByExtending.start(); 

        ThreadByImplementing threadByImplementing = new ThreadByImplementing();
        Thread thread = new Thread(threadByImplementing);
        thread.start(); // Start the thread
    }
}
